# Module 9 — Western Australia Government Programs 2026

**Category:** Government Programs  
**Region:** Western Australia  
**Accurate as of:** October 2026

---

> **Key WA advantage:** Western Australia is the only state with a dedicated state battery rebate that stacks on top of the federal program. WA homeowners can access the highest combined battery incentives in Australia. This is a powerful and genuine talking point.

---

## Program Summary Table

| Program | Status | Benefit | Key Conditions |
|---------|--------|---------|----------------|
| **WA Residential Battery Scheme (State)** | ✅ Active | $1,300 rebate (Synergy customers) or $3,800 (Horizon Power customers) — applies to first 10kWh of storage | Battery on CEC approved list; VPP participation mandatory; battery installed from 1 Jul 2025 |
| **WA No-Interest Loan** | ✅ Active | Up to $10,000 interest-free loan | Combined household gross income under $210,000/year |
| **Federal Cheaper Home Batteries Program** | ✅ Active | ~30% off eligible batteries (~$2,520 for 10kWh) — stackable with WA state rebate | No means test. New or existing solar. |
| **Federal STC Solar Rebate (SRES)** | ✅ Active | Upfront point-of-sale solar discount via STCs. WA Zone 1/2 = high STC value. | Eligible solar installation by accredited installer |
| **Distributed Energy Buyback Scheme (DEBS)** | ✅ Active | WA's solar export incentive — rates vary by time of export (peak, off-peak, shoulder) | WA solar owners on Synergy network who export to the grid |

---

## WA Residential Battery Scheme — Full Detail

### How Much Can WA Customers Get?

| Customer Type | State Rebate | Federal Rebate (10kWh) | Combined |
|---------------|--------------|------------------------|----------|
| Synergy (Perth metro) | $1,300 | ~$2,520 | **~$3,820** |
| Horizon Power (regional WA) | $3,800 | ~$2,520 | **~$6,320** |

> **This is a headline talking point for WA calls.** "WA homeowners are in one of the best positions in the country — you can stack the state rebate on top of the federal program."

### Key Eligibility Requirements

| Requirement | Detail |
|-------------|--------|
| Install date | Battery must be installed on or after 1 July 2025 |
| Approved battery | Must appear on the Clean Energy Council (CEC) approved battery list |
| VPP participation | **Mandatory** — not optional. Battery must be enrolled in a Virtual Power Plant program. |
| Technical requirements | From 1 May 2026: new technical requirements apply for systems on the SWIS (Western Power network) |
| Scheme cap | 100,000 households — runs until 2027 or cap is reached, whichever comes first |
| Annual decrease | Rebate amount decreases annually from 2026 to 2030 |

---

## Synergy vs Horizon Power

| Feature | Synergy | Horizon Power |
|---------|---------|---------------|
| Coverage | Perth metro and surrounding areas | Regional and remote WA |
| WA state rebate | $1,300 | $3,800 |
| Why the difference | Metro areas have better energy access and lower baseline energy costs | Regional areas have higher energy costs — larger rebate reflects this |

---

## VPP (Virtual Power Plant) — What It Is and How to Explain It

A Virtual Power Plant connects multiple home batteries into a coordinated network. When the electricity grid is under stress (e.g., very hot days, peak demand), Synergy can temporarily draw a small amount of energy from enrolled batteries to help stabilise the grid.

**Key points for customers:**
- The home battery **always prioritises the home first**
- Grid participation is occasional and limited — not constant
- In exchange, the homeowner receives the WA state battery rebate
- It is similar to a demand response agreement — the customer provides a grid service and is compensated through the rebate

### VPP Script for Calls

> **Prospect:** "What's this VPP thing I have to join?"
>
> **Setter:** "It's a Virtual Power Plant — basically a network of home batteries that work together to support the electricity grid on very hot days or at peak times. The important thing to know is your battery still prioritises your home first. Synergy might occasionally draw a small amount of stored energy from the grid side, but in exchange you get access to the WA state rebate. Most customers find it a very fair trade. Our consultant will explain exactly how it works for your specific setup."

---

## WA No-Interest Loan

| Feature | Detail |
|---------|--------|
| Maximum loan amount | $10,000 |
| Interest rate | 0% — no interest |
| Income eligibility | Combined gross household income under $210,000/year |
| Can be combined with | State rebate + federal rebate (all three can stack) |

> **⚠️ Do not confirm loan amounts or income thresholds on the call.** Always say: "Our consultant will walk you through the full eligibility including the interest-free loan options at the free audit." Eligibility details are subject to verification and can change.

---

## DEBS — Distributed Energy Buyback Scheme

WA's version of a feed-in tariff — but structured differently. DEBS pays time-of-use rates for exported solar:

- Higher rates during peak demand periods
- Lower rates during off-peak and shoulder periods

DEBS rates are set by the WA government and subject to change annually. Do not quote specific DEBS rates on calls — direct rate questions to the consultant.

---

## Live Call Scripts for WA

### Stacking the Rebates on a Call

> **Setter:** "Here's something that might surprise you — Western Australia is actually in one of the best positions in the country for battery incentives right now. There's the federal battery rebate that gives you around 30% off a home battery, and on top of that there's a WA state rebate as well. If you're on the Synergy network in Perth, you're looking at roughly $3,800 or more in combined rebates on a standard 10 kilowatt-hour battery — before we even talk about the interest-free loan options. Would it be worth getting the actual numbers from one of our local consultants?"

### For Horizon Power (Regional WA) Customers

> **Setter:** "Because you're in a regional area on the Horizon Power network, your state rebate is actually higher than metro Perth customers — it's $3,800 through the state scheme on top of the federal rebate. Regional WA customers tend to have some of the highest energy costs in the country, so the savings from battery storage are also some of the most significant. Let's get you a free audit and show you the full picture."

### Full WA Pitch — Urgency Close

> **Setter:** "The WA state rebate actually decreases every year from 2026 to 2030, and the scheme is capped at 100,000 households — so it does have a natural end point. Combined with the federal rebate stepping down every 6 months, there's genuinely a window here where the incentives are at their strongest. Would it make sense to at least get the numbers now while the rebates are still at this level?"

---

## WA Incentive Stacking — Quick Reference Card

Use this during calls to summarise the WA opportunity:

```
WA 10kWh Battery — Synergy Customer (Perth metro)
─────────────────────────────────────────────────
Federal Cheaper Home Batteries Program:  ~$2,520
WA Residential Battery Scheme (Synergy):  $1,300
─────────────────────────────────────────────────
Combined rebate estimate:               ~$3,820

PLUS: Up to $10,000 no-interest loan (income < $210k)

WA 10kWh Battery — Horizon Power Customer (Regional WA)
────────────────────────────────────────────────────────
Federal Cheaper Home Batteries Program:  ~$2,520
WA Residential Battery Scheme (Horizon):  $3,800
────────────────────────────────────────────────────────
Combined rebate estimate:               ~$6,320
```

---

## What NOT to Say on WA Calls

| ❌ Do NOT say | ✅ Say instead |
|---------------|---------------|
| "You'll get exactly $X,XXX" | "Around 30% off — your consultant will give you the exact figure" |
| "The VPP won't affect you at all" | "Your battery prioritises your home first — our consultant will explain the VPP in detail" |
| "You definitely qualify for the $10k loan" | "There's a no-interest loan option — eligibility is confirmed at the audit" |
| "The WA rebate won't change" | "The rebate decreases each year, so acting sooner gets you more" |

---

## Knowledge Check

**Q1:** What is the WA state battery rebate for Synergy customers vs Horizon Power customers?  
**A:** Synergy (Perth metro): $1,300. Horizon Power (regional WA): $3,800. Both stack on top of the federal ~30% rebate.

**Q2:** Is VPP participation required for the WA Residential Battery Scheme?  
**A:** Yes — VPP participation is mandatory, not optional.

**Q3:** What is the income threshold for the WA no-interest loan, and how much can be borrowed?  
**A:** Combined gross household income under $210,000/year — up to $10,000 interest-free.

**Q4:** Can the WA state rebate and the federal battery rebate be combined (stacked)?  
**A:** Yes — they can be stacked. This is the core WA incentive talking point.

---

## Course Complete — Quick Reference Summary

All 9 modules complete. Here's your one-page cheat sheet for live calls:

| Product | Best For | Core Message |
|---------|----------|--------------|
| Energy Independence | High bill payers, blackout-concerned | Full solar + battery, 90%+ self-sufficiency, Export Trap fix |
| Energy Starter | No solar yet | Premium install, hybrid-ready, spend once spend right |
| Energy Upgrade | Existing solar + still high bills | Battery retrofit, capture daytime solar for night-time use |
| Commercial | Business decision-makers | ROI-first energy strategy, 30–50% cost reduction |
| EV Solutions | EV owners or prospective buyers | $1/100km solar charging, cross-sell with any product |

| Region | Key Incentives 2026 |
|--------|---------------------|
| QLD (all) | Federal battery rebate ~30% (no means test). QLD Battery Booster closed. |
| SEQ | Solar Sharer Offer (free 11am–2pm from 1 Jul 2026). FiT 3–10¢. |
| WA | State rebate $1,300 (Synergy) or $3,800 (Horizon) + federal stacking + $10k no-interest loan. |

---

*Previous: [Module 8 — SEQ Programs](08-seq-programs.md) | [Return to Index](00-overview.md)*
