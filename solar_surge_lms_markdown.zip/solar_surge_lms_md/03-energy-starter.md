# Module 3 — Energy Starter

**Category:** Product  
**Type:** Entry Solar with Hybrid-Ready Inverter  
**Target prospect:** Homeowners without solar who want to start now and stay battery-ready

---

## What Is It

Energy Starter is Solar Surge's entry-level residential solar product — but it is not a budget system. It is a premium solar installation built with **battery-ready architecture from day one**.

Most cheap solar installs use a standard string inverter. When the homeowner later wants to add a battery, the inverter must be ripped out and replaced — costing thousands extra. Energy Starter uses a **hybrid-ready inverter**, so adding a battery later is plug-and-play with no inverter replacement and no rewiring.

### Key Stats

| Stat | Value |
|------|-------|
| Daytime energy cost reduction | 70–80% |
| Future upgrade waste | $0 (inverter is already battery-ready) |
| Panel warranty | 25 years |
| Cheap solar failure rate (within 3 years) | ~40% |
| Install crew | Solar Surge's own licensed local electricians — no subcontractors |

---

## Three Core Components

| Component | Detail |
|-----------|--------|
| **Tier-1 Solar Panels** | Highest-rated panels with 25-year performance warranty. Built for intense heat, severe storms, and coastal salt air. |
| **Hybrid-Ready Inverter** | Smart inverter engineered for Australian grids. Works with solar today, accepts a battery tomorrow — no replacement needed. |
| **In-House Licensed Install** | Every job completed by Solar Surge's own licensed local electrical teams in QLD, WA, and NSW. No subcontractors, no shortcuts. |

---

## Who Is This For — Call Qualification

- [ ] Homeowner who does not yet have solar
- [ ] Wants immediate daytime savings
- [ ] May not be ready to invest in a battery right now — but wants the option later
- [ ] Has received cheap solar quotes and needs to understand the risk
- [ ] Home is in QLD, WA, or NSW service area

> **⚠️ Do NOT pitch Energy Starter to someone who already has solar panels.** That customer needs Energy Upgrade (Module 4). Always ask: *"Do you currently have solar panels on your roof?"*

---

## The "Spend Once, Spend Right" Principle

This is the core pitch differentiator.

- Cheap solar is often cheap because of inferior components and undertrained crews
- ~40% of budget solar systems underperform within 3 years
- When they fail, the original company is often gone — the homeowner pays a new installer to start over
- A non-hybrid-ready inverter means paying thousands extra to swap it out when adding a battery later
- **"A strategic solar foundation isn't about spending more — it's about spending once."**

---

## Live Call Scripts

### Opener — No-Solar Homeowner

> **Setter:** "Hi [Name], calling from Solar Surge Australia. Quick question — do you currently have solar panels, or are you still running 100% off the grid?"
>
> *[No solar confirmed]*
>
> **Setter:** "Perfect — so you're probably paying full price for every unit of electricity you use, including all those hot summer days running the air con. A properly engineered solar system in [QLD/WA] can eliminate 70 to 80% of your daytime electricity costs — air con, appliances, pool pumps — all running on free energy from your roof."
>
> "Here's what makes Solar Surge different: we install what's called a hybrid-ready inverter. That means when you're ready to add a battery down the track, it's plug-and-play — no expensive inverter replacement needed. We've seen homeowners get stung twice because their cheap system wasn't battery-ready. Would you be interested in a free audit to see what this would look like for your home?"

### Handling the "I Have a Cheap Quote" Scenario

> **Prospect:** "I've already got a quote for solar — it's pretty cheap."
>
> **Setter:** "That's great you're looking into it. Can I ask — do you know if that quote includes a hybrid-ready inverter? The reason I ask is around 40% of budget solar systems underperform within 3 years, and if the inverter isn't battery-compatible, adding storage later means replacing the whole thing. We call it spending twice. Our free audit would show you a direct comparison so you can make an informed call. Would that be worth 30 minutes of your time?"

---

## Objection Handling

### "Solar is too expensive — I'll wait until prices come down."

> **[Reframe]** "Prices have actually been falling for years and many experts believe we're near the floor now. More importantly, every month you wait is another month of full electricity bills. The average Queensland home spends $2,000–$3,000 a year on electricity. That's money gone. The audit will show you the actual payback period — most homeowners hit payback in 3–5 years, then enjoy 20+ years of near-free power."

### "I don't want installation disruption."

> **[Reassure]** "Most Energy Starter installs are completed in a single day by our own licensed local team. No subcontractors, no mess left behind. Our team handles everything including paperwork with your network provider."

### "I'm not home during the day so solar won't help me."

> **[Educate]** "That's actually the perfect reason to look at our Energy Starter — because we install a hybrid-ready inverter. When you add a battery later, all that daytime solar gets stored and used when you're home at night. And in the meantime, pool pumps, hot water systems, and appliances still run during the day. The audit will show you exactly what you'd save."

---

## Knowledge Check

**Q1:** Why does Solar Surge install a hybrid-ready inverter with Energy Starter?  
**A:** So a battery can be added later without replacing the inverter — it is plug-and-play. This avoids the cost of a double install.

**Q2:** What statistic do we use when a prospect mentions a cheap solar quote?  
**A:** Around 40% of cheap solar systems underperform within 3 years.

**Q3:** What is the typical daytime energy cost reduction from a properly engineered solar system?  
**A:** 70–80%.

---

*Previous: [Module 2 — Energy Independence](02-energy-independence.md) | Next: [Module 4 — Energy Upgrade](04-energy-upgrade.md)*
