# Module 4 — Energy Upgrade

**Category:** Product  
**Type:** Battery Retrofit for Existing Solar  
**Target prospect:** Homeowners with solar who still receive high electricity bills

---

## What Is It

Energy Upgrade is specifically for homeowners who already have solar panels but are still experiencing high electricity bills. This is a very common frustration — and it is fully explainable.

Solar panels only save money during daylight hours. Without a battery, excess energy is exported to the grid for as little as 4 cents per kWh, then bought back in the evening for 30 cents or more. The fix is storage — and Solar Surge retrofits a premium battery system to the existing setup.

> **These prospects are warm leads.** They went solar to save money and it has not fully worked. They are already in the market for a solution. Your job is to show them that the fix exists.

---

## Key Stats

| Stat | Value |
|------|-------|
| Self-sufficiency target (post-upgrade) | 90%+ |
| Export gap | 4¢ sold vs 30¢+ bought back |
| Blackout protection | Included as standard |
| Monitoring | 24/7 live dashboard via phone app |

---

## The Three-Step Retrofit Process

| Step | Name | What Happens |
|------|------|--------------|
| 1 | **Inverter Check** | Assess the existing inverter for battery compatibility. Data-driven — no guesswork. |
| 2 | **Efficiency Optimisation** | Analyse household energy usage patterns and size the battery for maximum self-consumption. |
| 3 | **Safe Retrofitting** | Licensed electricians integrate the battery with the existing setup. Full compliance, full testing. |

---

## Who Is This For — Call Qualification

- [ ] Has existing solar panels (installed by anyone — does not have to be Solar Surge)
- [ ] Still receiving high electricity bills despite having solar
- [ ] Away from home during the day — can't use daytime solar generation
- [ ] Has experienced blackouts and wants backup power
- [ ] Homeowner in QLD, WA, or NSW

> **⚠️ If they do NOT have solar panels, route them to Energy Starter (Module 3) or Energy Independence (Module 2) instead.**

---

## Key Differentiator — Blackout Protection

Most solar-only systems shut off automatically when the grid goes down. This is a safety requirement — without a battery, the system cannot safely operate in isolation.

With an Energy Upgrade battery retrofit, the home stays powered during a blackout. The prospect's fridge, lights, and internet continue working while neighbours are in the dark. This is included as standard.

---

## Live Call Scripts

### Opener — Existing Solar Homeowner

> **Setter:** "Hi [Name], this is [Name] from Solar Surge Australia. I'm reaching out because you've got solar panels — is that right? Quick question: has your electricity bill dropped as much as you expected when you went solar?"
>
> *[They often say no, or say it's still too high]*
>
> **Setter:** "Yeah, that's really common and I can tell you exactly why. Your panels are working hard during the day — but if you're not home, or you're using most of your power in the evenings, all that energy is being exported to the grid for about 4 cents. Then at night you're buying it back for 30 cents. It's like filling your car with free fuel and then pouring most of it down the drain. The fix is a battery — and what Solar Surge does is retrofit a premium battery to your existing system so you capture that daytime energy and use it when you actually need it. We'd love to book you in for a free audit. Would [day] or [day] work?"

### Handling "Another Company Installed My Solar"

> **Prospect:** "My solar was installed by someone else — can you still help?"
>
> **Setter:** "Absolutely — this is actually really common. Step one is always an inverter assessment. Our licensed team will check whether your existing inverter is battery-compatible or needs an upgrade. The process is data-driven — we won't guess or just sell you something that doesn't work. And if your inverter is compatible, the retrofit is seamless. Worth getting that assessed for free?"

---

## Objection Handling

### "I'll just wait — feed-in tariffs might go back up."

> **[Educate]** "Feed-in tariffs have actually been declining for years — they used to be 44–66 cents per kWh on the old Queensland Solar Bonus Scheme, and today in South East Queensland the market rate is typically 3–10 cents depending on your retailer. The trend is down, not up. Battery storage is the proven answer. And with the current federal battery rebate offering around 30% off right now, the timing is actually better than ever."

### "My inverter is old — I'm worried it won't be compatible."

> **[Reassure]** "That's exactly what the free audit is for. Our licensed team does a proper inverter compatibility check — we'll tell you upfront whether it works as-is, needs a firmware update, or needs replacing. There's no guesswork and no commitment on your part. You'll have all the facts before making any decision."

### "How long until I get my money back?"

> **[Bridge]** "That's a great question for the audit — our consultant will model your specific situation: how much solar you're generating, how much you're currently exporting, and your night-time usage. That gives you a real payback figure, not a guess. Plus with the federal battery rebate currently available, the upfront cost is significantly lower than it was 12 months ago."

---

## Knowledge Check

**Q1:** A prospect says their solar was installed by a different company. What is the first step Solar Surge takes?  
**A:** Conduct a free inverter compatibility check to determine if it can support a battery. We never guess and we never commit before assessing.

**Q2:** What happens to a solar-only system (no battery) during a power blackout?  
**A:** The solar system shuts off. The home loses power even though the sun is shining — this is a grid-safety requirement for solar-only setups. An Energy Upgrade with battery provides blackout protection as standard.

**Q3:** Name the three steps in the Energy Upgrade retrofit process.  
**A:** Inverter Check → Efficiency Optimisation → Safe Retrofitting

---

*Previous: [Module 3 — Energy Starter](03-energy-starter.md) | Next: [Module 5 — Commercial Solar](05-commercial.md)*
