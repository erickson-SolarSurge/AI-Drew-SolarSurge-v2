# Module 1 — Welcome & Overview

**Category:** Orientation  
**Prerequisite:** None — start here

---

## About Solar Surge Australia

Solar Surge is a premium solar and battery installer operating across Queensland, Western Australia, and New South Wales. We are not a volume installer — we engineer complete energy ecosystems tailored to each home and business, installed by our own licensed electrical teams with no subcontractors.

| Metric | Value |
|--------|-------|
| Homes powered | 3,500+ |
| Google rating | 4.9 ★ |
| Panel warranty | 25 years |
| Battery warranty | 10 years |
| After-hours support | 24/7 system monitoring |

---

## Our Product Suite

| Product | Best For | Core Benefit |
|---------|----------|--------------|
| Energy Independence | Homeowners wanting maximum bill reduction | Solar + battery + inverter full ecosystem, 90%+ self-sufficiency |
| Energy Starter | Homeowners new to solar | Premium panels + hybrid-ready inverter, battery-ready from day one |
| Energy Upgrade | Existing solar owners still getting bill shock | Battery retrofit to existing solar system |
| Commercial Solar | Businesses with high energy costs | Custom-engineered ROI-first energy strategy |
| EV Solutions | EV owners or prospective EV buyers | Solar-powered EV charging, V2H future-ready |

---

## Your Role as an Appointment Setter

Your job is **not to sell** — it is to book qualified appointments for field consultants. A high-quality booked appointment means:

- The prospect owns their home (not renting)
- They have a genuine pain point (high bills, existing solar with continued bill shock, business energy costs)
- Both decision-makers can attend the in-home audit (partner/spouse)
- The address is in one of Solar Surge's service areas

> **Remember:** You are booking a free Strategic Energy Audit — no pressure, no commitment. Frame every appointment this way.

---

## Key Principles for Every Call

1. **Lead with the problem, not the product.** Identify the Export Trap or bill pain before introducing Solar Surge.
2. **Qualify before you pitch.** Homeowner? In service area? Real pain point?
3. **Always seek both decision-makers.** "Is your partner usually home on [day]? Ideal to have both of you there."
4. **Use government rebates as urgency.** Rebate values decline — "the sooner you act, the higher the rebate."
5. **Your closer is the audit, not the product.** Book the appointment; let the consultant close.

---

*Next: [Module 2 — Energy Independence](02-energy-independence.md)*
