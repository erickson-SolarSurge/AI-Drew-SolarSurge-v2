# Module 8 — South East Queensland Programs 2026

**Category:** Government Programs  
**Region:** South East Queensland (SEQ) — Gold Coast, Brisbane, Logan, Ipswich, Sunshine Coast  
**Accurate as of:** October 2026

---

> **Why SEQ gets its own module:** SEQ operates on the Energex electricity distribution network, which has different feed-in tariff rules than regional QLD (Ergon). SEQ also has access to the new Solar Sharer Offer — a significant and very fresh talking point for calls in this area.

---

## Program Summary Table

| Program | Status | Benefit | Who Qualifies |
|---------|--------|---------|---------------|
| **Solar Sharer Offer (SSO)** | 🆕 Live from 1 Jul 2026 | 3 hours of free electricity daily (11am–2pm AEST) via opt-in regulated tariff | SEQ residential customers with a smart (advanced digital) meter — no solar required |
| **Federal Cheaper Home Batteries Program** | ✅ Active | ~30% off eligible battery systems (same as all QLD) | Homeowners and small businesses — no means test |
| **Federal STC Solar Rebate** | ✅ Active | Upfront point-of-sale discount via STCs. SEQ is Zone 2 — high solar resource and STC value. | Homeowners installing eligible solar |
| **SEQ Feed-in Tariff** | ✅ Active | ~3–10¢/kWh — deregulated, no mandated minimum on Energex network | Solar owners who export to the grid in SEQ |
| **Solar Bonus Scheme (44¢ legacy FiT)** | ⚠️ Legacy only | 44¢/kWh for existing recipients only — expires 1 July 2028 | Existing recipients maintaining eligibility — NOT new customers |
| **Supercharged Solar for Renters** | 🆕 New | Up to $3,500 for QLD landlords installing solar on rental properties | QLD landlords — open since December 2025 |

---

## Solar Sharer Offer — Full Detail

This is Solar Surge's freshest and most powerful conversation opener for SEQ calls. It launched 1 July 2026.

### What It Is

The Solar Sharer Offer (SSO) is a new opt-in regulated electricity standing offer introduced by the Australian Government as part of reforms to the Default Market Offer (DMO). It is available in:
- South East Queensland (Energex network)
- New South Wales
- South Australia

### How It Works

| Feature | Detail |
|---------|--------|
| Free electricity window | **11am to 2pm AEST** daily |
| Duration | 3 hours per day |
| Requirement | Smart (advanced digital) meter |
| Solar required? | **No** — available to households with or without solar |
| Opt-in or automatic? | **Opt-in** — customers must sign up through their energy retailer |
| Retailer obligation | All retailers with 1,000+ customers in SEQ must offer it |
| Tariff type | Regulated standing offer under the AER's DMO framework |

### Why It Matters for Our Calls

The Solar Sharer Offer is valuable for Solar Surge in two distinct ways:

**1. Without solar:** Households can access free midday power by shifting usage (dishwasher, washing machine, pool pumps, EV charging) to 11am–2pm. This reduces bills without any installation. It's a Government-backed proof-point that daytime solar generation is abundant enough to give away.

**2. With solar + battery:** The Solar Sharer Offer becomes even more powerful. Customers can charge their battery during the free window (free energy input) and discharge it in the evening (displacing expensive grid power). It is an additional stacking benefit on top of solar + storage savings.

> **🔑 Key call insight:** The Solar Sharer Offer is a perfect opener for SEQ because it demonstrates that energy policy is shifting in favour of households who move usage to daytime. Solar + battery is the maximum expression of this strategy.

---

## The SEQ Feed-in Tariff Landscape

### Current Rate (2026)

- **Rate:** ~3–10¢/kWh (deregulated — varies by retailer, no mandated minimum)
- **Network:** Energex (South East Queensland)

This is a powerful selling point because it proves the Export Trap is real and significant.

### Historical Context

| Period | Rate | Notes |
|--------|------|-------|
| 2008–2012 | 44–66¢/kWh | Solar Bonus Scheme premium rates |
| Post-2012 | Progressive decline | As solar adoption grew, feed-in tariffs were reduced |
| 2026 | 3–10¢/kWh | Current deregulated market rate in SEQ |

> **Fact to use on calls:** "Feed-in tariffs in South East Queensland have fallen from 44 cents to basically 3–10 cents. If you're sending your power to the grid, you're selling it for a fraction of what you pay to buy it back."

### Solar Bonus Scheme (44¢ FiT) — Existing Recipients

- Only current recipients who enrolled before the scheme closed can receive 44¢/kWh
- They must maintain eligibility criteria to keep this rate
- Rate expires for all recipients on **1 July 2028**
- If a prospect mentions their 44¢ rate and asks about adding a battery: flag to your consultant, as this is a specific eligibility situation. Adding a battery or changing the system may affect their 44¢ eligibility — do not guess on this.

---

## Using the SEQ Feed-in Tariff Decline in Your Pitch

The falling FiT actually strengthens the battery case:

- Low FiT = the Export Trap is worse in SEQ than anywhere else
- Every unit exported earns less and less
- Storage is the only way to recapture the value of exported solar
- The Solar Sharer Offer confirms this: government policy now encourages households to **use solar energy rather than export it**

---

## Live Call Scripts for SEQ

### Solar Sharer Offer as an Opener

> **Setter:** "Hi [Name], quick question — are you aware of the new Solar Sharer Offer that just launched in South East Queensland in July? It's a government-backed offer that gives households three hours of completely free electricity every day between 11am and 2pm. You don't even need solar to access it. But here's the thing: if you have solar and a battery, you can charge your battery during those free hours and use that power in the evening — that's when the real savings stack up. Would it be worth chatting to one of our energy consultants to see what that combination could look like for your home?"

### Handling Feed-in Tariff Frustration

> **Prospect:** "I've had solar for years but my feed-in tariff has dropped so much it's barely worth it."
>
> **Setter:** "Yeah, that's a really common frustration. Feed-in tariffs in South East Queensland have gone from 44 cents years ago to basically 3 to 10 cents now depending on your retailer. And that gap is going to keep widening. The fix isn't more panels — it's storage. A battery means instead of exporting for 3 cents, you keep that energy and use it tonight. We'd love to show you the numbers on a free audit — you might be surprised how much you're losing to the grid right now."

### Prospect Without Solar — Solar Sharer + Starter Combo Pitch

> **Setter:** "So you've heard about the Solar Sharer Offer launching in SEQ — that's actually a great segue into what we do. That offer gives you 3 free hours at midday. But with solar panels, you're generating free energy all day. And with a battery on top, you store it and use it all night. The Solar Sharer Offer is basically a preview of how Australia's energy system is shifting — and the households that have solar and storage are in the best position to benefit. Would a free audit make sense?"

---

## SEQ vs Regional QLD — Key Differences for Setters

| Feature | SEQ (Energex) | Regional QLD (Ergon) |
|---------|---------------|----------------------|
| Feed-in tariff | 3–10¢/kWh (deregulated) | 8.66¢/kWh (regulated minimum) |
| Solar Sharer Offer | ✅ Available from 1 Jul 2026 | ✅ Available from 1 Jul 2026 (regional SSO mirroring SEQ rates approved by QCA) |
| Solar Bonus Scheme | ✅ Existing recipients still active | ✅ Existing recipients still active |
| Federal battery rebate | ✅ Same as all QLD | ✅ Same as all QLD |

---

## Knowledge Check

**Q1:** What is the Solar Sharer Offer and when is the free electricity window in SEQ?  
**A:** A new opt-in regulated tariff (from 1 July 2026) providing 3 hours of free electricity daily from 11am–2pm AEST. Available to any SEQ household with a smart meter — solar is not required.

**Q2:** What is the current feed-in tariff range for solar owners in SEQ (Energex network)?  
**A:** ~3–10¢/kWh — deregulated, varies by retailer, no mandated minimum.

**Q3:** Does a household automatically receive the Solar Sharer Offer?  
**A:** No — it is opt-in. Customers must sign up through their energy retailer.

**Q4:** What should you do if an existing solar customer mentions they're on the 44¢ Solar Bonus Scheme and asks about adding a battery?  
**A:** Do not advise on eligibility impact — flag it to the consultant. Adding or modifying a system may affect their legacy 44¢ FiT eligibility, and this is a specific technical/regulatory question for the audit.

---

*Previous: [Module 7 — QLD Programs](07-qld-programs.md) | Next: [Module 9 — WA Programs 2026](09-wa-programs.md)*
