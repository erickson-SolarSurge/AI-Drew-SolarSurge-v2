# Solar Surge Australia — New Hire LMS

**Version:** October 2026  
**Maintained by:** Emil Halili, Solar Surge Australia  
**Purpose:** New hire onboarding — product knowledge and government programs for appointment setters

---

## Module Index

| # | Module | Category | Key Topics |
|---|--------|----------|------------|
| 1 | [Welcome & Overview](01-welcome.md) | Orientation | LMS structure, company stats, how to use |
| 2 | [Energy Independence](02-energy-independence.md) | Product | Flagship solar + battery ecosystem, Export Trap, HSEP framework |
| 3 | [Energy Starter](03-energy-starter.md) | Product | Entry solar, hybrid-ready inverter, cheap solar reframe |
| 4 | [Energy Upgrade](04-energy-upgrade.md) | Product | Battery retrofit for existing solar owners |
| 5 | [Commercial Solar](05-commercial.md) | Product | Business energy engineering, ROI-first positioning |
| 6 | [EV Solutions](06-ev-solutions.md) | Product | Solar-powered EV charging, V2H, cross-sell scripts |
| 7 | [QLD Programs 2026](07-qld-programs.md) | Government | Federal battery rebate, STC solar rebate, closed state programs |
| 8 | [SEQ Programs 2026](08-seq-programs.md) | Government | Solar Sharer Offer, feed-in tariffs, landlord rebate |
| 9 | [WA Programs 2026](09-wa-programs.md) | Government | State battery rebate, no-interest loan, federal stacking |

---

## Company Quick Stats

| Stat | Value |
|------|-------|
| Homes powered | 3,500+ |
| Google rating | 4.9 ★ |
| States served | QLD, WA, NSW |
| Head office | 32 Junction Rd, Burleigh Heads QLD 4220 |
| Phone | 1300 206 321 |

---

## Service Areas

**Queensland:** Gold Coast, Brisbane, Logan, Ipswich, Toowoomba, Dalby, Sunshine Coast  
**Western Australia:** Perth, Fremantle, Joondalup, Mandurah, Rockingham, Canning Vale  
**New South Wales:** Newcastle, Central Coast, Lake Macquarie, Maitland

---

## How to Use This LMS

1. Work through each module in order before your first live shift
2. Read all sections — pay close attention to call scripts and objection handlers
3. Practice scripts out loud before going live
4. Complete the knowledge check at the end of each module
5. Reference these materials any time during your first 30 days

> **Goal:** Complete all 9 modules before your first live shift.
