# Module 7 — Queensland Government Programs 2026

**Category:** Government Programs  
**Region:** Queensland (all of QLD)  
**Accurate as of:** October 2026

---

> **⚠️ Critical before you call:** The Queensland state battery rebate (Battery Booster Program) closed in May 2024. Never tell a prospect this program is available. The current program is federal. See below for the full and accurate picture.

---

## Program Summary Table

| Program | Status | Benefit | Who Qualifies |
|---------|--------|---------|---------------|
| **Federal Cheaper Home Batteries Program** | ✅ Active | ~30% off eligible batteries (~$252/usable kWh for first 14kWh, stepping down every 6 months) | QLD homeowners and small businesses — no means test |
| **Federal STC Solar Rebate (SRES)** | ✅ Active | Point-of-sale upfront discount on solar panels via Small-scale Technology Certificates. QLD is Zone 1/2 — high STC value. | Any homeowner or small business installing eligible solar panels |
| **QLD Battery Booster Program** | ❌ Closed | Was a state battery rebate — closed to new applications May 2024 | No longer available for new applicants |
| **Feed-in Tariff — SEQ (Energex network)** | ✅ Active | ~3–10¢/kWh — deregulated, no mandated minimum, varies by retailer | Solar owners in South East Queensland |
| **Feed-in Tariff — Regional QLD (Ergon network)** | ✅ Active | 8.66¢/kWh regulated minimum, set by QCA annually from 1 July | Solar owners on Ergon Energy network (regional QLD) |
| **Solar Bonus Scheme (44¢ legacy FiT)** | ⚠️ Legacy only | 44¢/kWh for existing recipients — NOT available to new customers. Expires 1 July 2028. | Existing recipients only who have maintained eligibility |
| **Supercharged Solar for Renters** | 🆕 New | Up to $3,500 for QLD landlords who install solar on rental properties | QLD landlords — open since December 2025 |

---

## Federal Cheaper Home Batteries Program — Full Detail

This is the **primary incentive to mention on QLD calls**. It is a federal (Australian Government) program delivered through the Small-scale Renewable Energy Scheme (SRES).

### How It Works

- Delivered through Small-scale Technology Certificates (STCs) — same mechanism as the solar STC rebate
- Applied at **point of sale by the installer** — the customer receives the discount immediately, no waiting for a government cheque
- Applies to batteries with 5–100 kWh nominal capacity
- Applies to batteries added to **new OR existing** solar systems
- **No means test** — any eligible homeowner or small business qualifies

### Current Rebate Values (May–December 2026)

| Battery Size | Approx. Rebate |
|--------------|----------------|
| 10 kWh | ~$2,520–$2,720 |
| 13 kWh | ~$3,276–$3,536 |
| 14 kWh (cap) | ~$3,528–$3,808 (maximum) |
| Above 14 kWh | Only first 14 kWh of usable capacity qualifies |

- Current STC factor: **6.8** (from May 2026)
- Rebate steps down **every 6 months** (January and July)
- Program funded to **$7.2 billion** through to **2030**
- Program originally launched 1 July 2025 and expanded in December 2025 from $2.3B to $7.2B

### Urgency Language for Calls

> "The sooner you act, the higher the rebate — it steps down every six months."

---

## Federal STC Solar Rebate

- Applied automatically by the installer at point of sale — the customer just pays the reduced price
- QLD falls in **Zone 1 or Zone 2** depending on location — both zones generate high STC values due to Queensland's excellent solar resource
- For 2026: multiplier is 5 years of certificates (scheme winds down annually until 2030)

### Zone Reference (QLD)

| Zone | Region | STC Multiplier |
|------|--------|----------------|
| Zone 1 | Far North Queensland | 1.622 |
| Zone 2 | Most of QLD (including Brisbane, Gold Coast) | 1.536 |

---

## Feed-in Tariff Context

Feed-in tariffs pay solar owners for electricity exported to the grid. Understanding the FiT context is critical for the Export Trap pitch.

| Network | Rate | Regulation |
|---------|------|------------|
| SEQ (Energex) | ~3–10¢/kWh | Deregulated — no mandated minimum |
| Regional QLD (Ergon) | 8.66¢/kWh | Regulated minimum set by QCA annually |

**Old Solar Bonus Scheme (44¢ FiT):**
- Available to customers who enrolled in the scheme prior to its closure
- Not available to new applicants — do not reference it as a current benefit
- Existing recipients can maintain their 44¢ rate until 1 July 2028 as long as they maintain eligibility criteria

---

## How to Use Rebates on a Call

### Introducing the Federal Battery Rebate

> **Setter:** "One thing worth knowing — there's currently a federal battery rebate program running across Queensland that's giving homeowners around 30% off the cost of a home battery system. The rebate actually steps down every six months, so the longer you wait, the lower it gets. Our consultant will show you exactly what you'd be eligible for in the free audit. It's definitely worth getting the numbers while the rebate is still at its current level."

### Correcting a Prospect Who Mentions the QLD Battery Booster

> **Prospect:** "I heard Queensland has a battery rebate you can apply for?"
>
> **Setter:** "You might be thinking of the old Queensland Battery Booster — that one actually closed back in May 2024. But the good news is there's a federal program running right now that's available across Queensland — the Cheaper Home Batteries Program. It's giving homeowners around 30% off and it's funded through to 2030. Our consultant will walk you through exactly what that means for your specific installation."

---

## What NOT to Say on QLD Calls

| ❌ Do NOT say | ✅ Say instead |
|---------------|---------------|
| "The QLD Battery Booster is available" | "The QLD Battery Booster closed in May 2024 — but the federal program is still running" |
| "You'll get a $X,XXX rebate" | "Around 30% off — your consultant will give you the exact figure at the audit" |
| "The rebate won't change" | "The rebate steps down every 6 months — so the timing matters" |
| "You get 44 cents feed-in" | "That was the old scheme — current rates are 3–10 cents in SEQ" |

---

## Knowledge Check

**Q1:** A prospect asks about the "QLD Battery Booster." What do you tell them?  
**A:** The program closed in May 2024. Redirect to the Federal Cheaper Home Batteries Program (~30% off, no means test, available across QLD).

**Q2:** Is the Federal Cheaper Home Batteries Program means-tested?  
**A:** No — any eligible homeowner or small business qualifies regardless of income.

**Q3:** How often does the federal battery rebate step down?  
**A:** Every 6 months — in January and July.

**Q4:** Can the federal battery rebate apply to an existing solar system (retrofit)?  
**A:** Yes — it applies to batteries added to new OR existing solar PV systems.

---

*Previous: [Module 6 — EV Solutions](06-ev-solutions.md) | Next: [Module 8 — SEQ Programs 2026](08-seq-programs.md)*
