# Module 5 — Commercial Solar

**Category:** Product  
**Type:** Custom Business Energy Engineering  
**Target prospect:** Business owners and decision-makers with high operational energy costs

---

## What Is It

Commercial Solar is Solar Surge's offering for businesses — warehouses, retail, manufacturing, offices, and more. Unlike residential solar, commercial energy use is shaped by shift patterns, demand charges, peak pricing, and seasonal variation. Solar Surge designs around those operational realities, not just roof space.

> **Key message:** "Commercial solar isn't a green initiative — it's a financial strategy. The ROI is measurable from day one."

---

## Key Stats

| Stat | Value |
|------|-------|
| Typical energy cost reduction (year 1) | 30–50% |
| Energy as operating cost rank | 2nd largest for most Australian businesses |
| Install team | Solar Surge's own licensed commercial electricians — no subcontractors |

---

## What Makes It Different from a Residential System

| Factor | Residential | Commercial |
|--------|-------------|------------|
| Design basis | Household usage profile | Shift patterns, demand charges, peak pricing, seasonal variation |
| Financial output | Bill reduction estimate | Detailed ROI analysis + payback period projections |
| Engineering scope | Standard roof mount | Custom design around operational requirements |
| Install team | Licensed residential electricians | Licensed commercial electricians with workplace safety compliance |
| Commitment process | Free energy audit | Free commercial audit with financial modelling before any commitment |

---

## Three Pillars of Commercial Solar Surge

### 1. Financial Modelling First
Detailed ROI analysis, payback period calculations, and energy cost projections are provided before any commitment. The business sees the numbers before spending a dollar.

### 2. Operational Integration
The system is designed around the business's actual operations — shift patterns, peak demand periods, and seasonal variations. The system works with the business, not against it.

### 3. Licensed Commercial Teams
Solar Surge's own licensed commercial electricians handle every installation. Full compliance, workplace safety requirements, and ongoing accountability.

---

## Who Is This For — Call Qualification

- [ ] Business owner or financial decision-maker
- [ ] Business with high monthly electricity costs
- [ ] Operates in QLD, WA, or NSW
- [ ] Has daytime operations (solar savings align with production hours)
- [ ] Open to a data-driven ROI conversation — not just a quote

> **⚠️ Confirm the decision-maker.** Ask: *"Are you the business owner, or is there someone else who handles energy and operating costs for the business?"*

---

## Live Call Scripts

### Initial Outreach — Finding the Decision-Maker

> **Setter:** "Hi, I'm looking for the person who handles electricity costs for the business — is that you or the business owner?"
>
> *[Confirm decision-maker before continuing]*

### Core Pitch — Business Owner or FM

> **Setter:** "We work with businesses across [QLD/WA] to protect their margins from rising energy tariffs. Electricity is typically the second-largest operating cost for most Australian businesses, and every quarter it seems to go up. What Solar Surge does is custom-engineer a commercial solar system around your actual operations — including your shift patterns and peak demand periods — and we model the ROI and payback period before you commit to anything. Most businesses see a 30 to 50% reduction in energy costs in year one. Would a free commercial energy audit be worth 30 minutes of your or your owner's time?"

---

## Objection Handling

### "We lease our building — I can't put solar on it."

> **[Qualify]** "That's a fair point. Some leases do allow solar with landlord permission, especially long-term leases where the landlord may see added property value. It's worth checking your lease terms — we can help you understand what questions to ask your landlord. The financial case is often compelling for both parties."

### "Our usage varies too much — solar won't work for us."

> **[Educate]** "That's exactly why we do operational integration modelling — we design around your actual load profile, including seasonal variation and peak demand. The system works with your business, not against it. Let our commercial team run the numbers — you'll see what it actually looks like for your specific situation."

### "We're not focused on green initiatives right now."

> **[Reframe]** "Completely understood — and that's not how we position this. Commercial solar at Solar Surge is purely a financial decision. Think of it as locking in your energy costs at a fraction of what you're paying now, with a measurable payback period. The businesses that thrive next decade won't be the ones absorbing rising tariffs — they'll be the ones that eliminated them. The audit is free and data-driven — no green agenda, just numbers."

---

## Knowledge Check

**Q1:** What does Solar Surge provide to commercial prospects before they commit to anything?  
**A:** Detailed ROI analysis, payback period calculations, and energy cost projections. Data-driven decisions, not sales pressure.

**Q2:** What is the typical operational energy cost reduction in year one for a commercial system?  
**A:** 30–50%.

**Q3:** How is a commercial system design different from a residential one?  
**A:** Commercial systems are designed around shift patterns, demand charges, peak pricing, and seasonal variation — not just roof space and household usage.

---

*Previous: [Module 4 — Energy Upgrade](04-energy-upgrade.md) | Next: [Module 6 — EV Solutions](06-ev-solutions.md)*
