# Module 2 — Energy Independence

**Category:** Product  
**Type:** Solar + Battery Full Ecosystem  
**Target prospect:** Homeowners wanting maximum bill reduction and energy security

---

## What Is It

Energy Independence is Solar Surge's signature product — a precision-engineered ecosystem combining solar panels, a high-capacity battery, and a smart hybrid inverter. The goal is to turn the customer's home into its own power station, achieving 90%+ energy self-sufficiency.

### Key Stats

| Stat | Value |
|------|-------|
| Self-sufficiency target | 90%+ |
| Export trap gap | ~4¢/kWh exported vs 30¢+ bought back |
| Panel warranty | 25 years |
| Battery warranty | 10 years |
| Blackout protection | Included as standard |

---

## The Export Trap — Core Concept

> **This is the central problem you must communicate on every call.**

Australian solar owners often still experience bill shock because:
- Panels produce the most energy during the day (when the household is often away)
- Excess daytime energy is exported to the grid for **~4 cents per kWh**
- In the evening, when energy is actually needed, it is purchased back from the grid for **30 cents or more**
- That is a **650% markup on the customer's own energy**

The solution is not more panels. The solution is **smart storage**.

---

## The Four Stages — HSEP Framework

Memorise this. It is the backbone of your Energy Independence pitch.

| Stage | Name | What It Does |
|-------|------|--------------|
| 1 | **Harvest** | Tier-1 panels capture maximum energy from Australia's intense sun. Built for hail, heat, coastal salt air. 25-year performance warranty. |
| 2 | **Store** | High-capacity lithium battery stores excess daytime energy instead of exporting at 4¢. Keeps it for night-time use. |
| 3 | **Empower** | Smart hybrid inverter manages flow between solar, battery, and grid automatically 24/7. No manual switching. |
| 4 | **Protect** | Built-in blackout protection keeps the home powered when the grid fails. Standard — not an add-on. |

---

## Who Is This For — Call Qualification Checklist

Use these qualifiers during the call before pitching:

- [ ] Paying high electricity bills — especially evenings or overnight
- [ ] Getting bill shock despite already having solar (Export Trap in action)
- [ ] Concerned about power outages — wants blackout protection
- [ ] Planning to stay in the home long-term — sees it as an investment
- [ ] Homeowner in QLD, WA, or NSW (**must own the property**)

> **⚠️ Do NOT pitch Energy Independence to renters.** Always confirm: *"Are you the homeowner, or are you renting?"*

---

## Aftercare — What to Mention When Asked

- **24/7 Proactive Monitoring** — Issues are fixed before the customer notices
- **Direct Expert Access** — No call centres; speak directly to the licensed professional who installed the system
- **Solar Surge Portal** — App to track energy production, savings, and system health in real time

---

## Live Call Scripts

### Opener — Identifying the Problem

> **Setter:** "Hi [Name], this is [Your Name] from Solar Surge Australia. Quick question for you — are you currently paying quite a bit on your electricity bill, especially in the evenings?"
>
> *[Prospect confirms high bills or says yes]*
>
> **Setter:** "That's actually really common — even with solar. A lot of homeowners in [QLD/WA] don't realise they're caught in what we call the Export Trap. During the day your panels produce heaps of energy, but if you're at work, all that power gets sent back to the grid for about 4 cents a kilowatt-hour. Then at night, you buy that same power back at 30 cents or more. Does that sound like your situation?"

### Transitioning to the Solution

> **Setter:** "What we do at Solar Surge is engineer what we call an Energy Independence system — solar panels combined with a high-capacity battery and a smart inverter. Instead of sending your power to the grid for peanuts, you store it and use it tonight. We've helped over 3,500 homes across QLD and WA cut their bills by 90% or more. One customer in Brisbane had a $6,700 bill — within one quarter, she was down over 90%."
>
> "What I'd love to do is book you in for a free Strategic Energy Audit with one of our licensed local consultants — completely no obligation. Does [day] or [day] work better for you?"

### Confirming the Appointment

> **Setter:** "Perfect. Just to confirm — you own the property at [address]? And is there a partner or spouse who'd be part of this decision? Ideal if both are there for the audit. Our consultant will do a full energy profile of your home and show you exactly what your system would look like and what you'd save. No pressure — it's just a data conversation."

---

## Objection Handling

### "I already have solar — why would I need this?"

> **[Reframe]** "That's actually the perfect situation for our Energy Upgrade — if you have solar and you're still getting bill shock, you're almost certainly caught in the Export Trap. Your panels are doing the work during the day but you're buying back your own power at night. A battery closes that gap. Would it be worth 30 minutes to find out exactly how much you're losing?"

### "It sounds expensive."

> **[Reframe]** "I completely understand — and that's exactly what the free audit covers. Our consultant will show you the actual numbers: what the system costs, what federal rebates you're eligible for, and what your payback period looks like. Most homeowners find it pays for itself in 3–5 years and then generates free electricity for 20+ years after that. That's why it's worth at least looking at the numbers, right?"

### "I need to think about it / talk to my partner."

> **[Advance]** "That makes total sense — which is why the audit is set up for both of you. Is your partner usually home in the evenings or on weekends? Let's book a time that works for both of you so you can look at the numbers together."

### "Will it actually work in our climate / harsh weather?"

> **[Reassure]** "Great question — that's exactly why we only use Tier-1 panels. They're specifically built to withstand intense heat, severe storms, and coastal salt air across QLD and WA. They come with a 25-year performance warranty. Our battery systems also have smart thermal management designed for Australian conditions."

---

## Knowledge Check

**Q1:** What is "The Export Trap"?  
**A:** Selling excess solar energy back to the grid at ~4¢/kWh, then buying it back at 30¢+ in the evening — a 650% markup on the customer's own energy.

**Q2:** What are the four stages of Energy Independence in order?  
**A:** Harvest → Store → Empower → Protect

**Q3:** Is blackout protection included or an extra add-on?  
**A:** Built-in as standard on every Energy Independence system — not an optional add-on.

---

*Previous: [Module 1 — Welcome](01-welcome.md) | Next: [Module 3 — Energy Starter](03-energy-starter.md)*
