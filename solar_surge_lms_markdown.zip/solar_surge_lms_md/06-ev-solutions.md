# Module 6 — EV Solutions

**Category:** Product  
**Type:** Solar-Powered EV Charging  
**Target prospect:** EV owners or households planning to get an EV, existing solar customers

---

## What Is It

EV Solutions pairs a smart EV charger with the customer's existing or new solar system. The result: charging from free solar energy instead of the grid or petrol.

> **Core pitch:** "Your roof is now your petrol station."

Solar-charged EV costs approximately **$1 per 100km** compared to **$15–$20+ per 100km on petrol**. Over the life of a vehicle, this represents tens of thousands of dollars in savings.

---

## Key Stats

| Stat | Value |
|------|-------|
| Solar EV charging cost | ~$1 per 100km |
| Petrol equivalent | ~$15–$20+ per 100km |
| Install type | Site assessment + switchboard upgrade if required + dedicated circuit + commissioning |
| Install crew | Solar Surge's own licensed electricians — no subcontractors |
| V2H readiness | Future-proofed for Vehicle-to-Home |

---

## Four Smart Features

| Feature | What It Does |
|---------|--------------|
| **Dynamic Load Balancing** | Automatically adjusts EV charger power draw based on the home's real-time consumption. Prevents circuit overloads and demand spikes while maximising solar usage. |
| **V2H Readiness** | Future-proofed for Vehicle-to-Home technology. When V2H arrives in Australia, the car can act as a mobile battery — powering the home during outages or peak tariff periods. |
| **App Control** | Schedule charging sessions, monitor solar usage, and track savings from a phone. Set to charge only when solar production is high. |
| **Full Site Assessment** | Solar Surge handles site assessment, switchboard upgrades (where required), dedicated circuit installation, and commissioning — end-to-end. |

---

## V2H — Explained Simply for Calls

**Vehicle-to-Home (V2H)** means the car's battery can discharge energy back into the home. In a future where V2H is widely available in Australia:
- The EV becomes a second home battery during blackouts
- The EV can discharge during peak tariff periods (e.g., 4–9pm) and recharge from cheap or free solar during the day
- A car with a 60–100kWh battery is significantly larger than a typical home battery (10–15kWh)

Solar Surge installs EV chargers with V2H in mind — so customers are not locked out of this technology when it becomes mainstream.

---

## EV Solutions as a Cross-Sell

EV Solutions is best positioned **alongside** another Solar Surge product, not as a standalone call objective.

**Cross-sell trigger questions:**
- "Do you or your household drive or plan to get an electric vehicle?"
- "Are you considering going electric in the next year or two?"

If yes → add EV Solutions to the audit booking.

> **💡 Full ecosystem opportunity:** A customer with Energy Independence + EV Solutions has essentially **zero** ongoing energy costs — their home runs on solar and their car runs on sunshine.

---

## Live Call Scripts

### Add-On Script (During Any Product Booking)

> **Setter:** "One more quick question — do you drive an electric vehicle, or is that something you're considering? The reason I ask is that customers who pair solar with a smart EV charger are essentially running their car on free sunshine. It costs about $1 per 100km charged from solar versus $15–$20 on petrol. Our free audit covers EV charging integration as well — worth including?"

### Standalone EV Opener

> **Setter:** "Hi [Name], calling from Solar Surge Australia. Quick question — you drive an electric vehicle — are you currently charging from the grid or from solar? Because if you're on grid power, you're paying about 30 cents per kilowatt-hour to charge. From solar, the same charge costs roughly $1 per 100km. We integrate smart EV chargers directly into your solar system so your car fuels itself from your roof. Would a free EV charging assessment be something worth looking at?"

---

## Objection Handling

### "I don't have an EV yet."

> **[Plant seed]** "Totally fine — when you do, you'll be ready. The cost of EVs is dropping significantly. Having a solar system with a hybrid-ready inverter means when you do make the switch, adding EV charging is straightforward. Our consultant can show you what the full ecosystem looks like in the audit — so you can plan ahead."

### "Can I just plug into a normal power outlet?"

> **[Educate]** "You can, but it's very slow and doesn't integrate with your solar. Without a smart charger, your EV could draw from the grid instead of solar, creating demand spikes that cost you money. A properly integrated smart charger is the difference between charging on free solar and paying grid rates for every kilometre."

### "I'm worried about a switchboard upgrade — sounds expensive."

> **[Reassure]** "We handle a full site assessment before any work is quoted. If a switchboard upgrade is needed, we'll tell you upfront and include it in the plan — no surprise costs. Many homes don't need it at all. The free audit is the right first step."

---

## Knowledge Check

**Q1:** What does Dynamic Load Balancing do in the EV charging system?  
**A:** Automatically adjusts the EV charger's power draw based on the home's real-time consumption — preventing circuit overloads while maximising use of available solar.

**Q2:** What does V2H (Vehicle-to-Home) readiness mean for a customer's future?  
**A:** When V2H technology becomes mainstream in Australia, the car's battery can discharge energy back into the home — acting as a large mobile battery during outages or peak tariff periods.

**Q3:** What is the approximate cost per 100km when an EV is charged from solar?  
**A:** Approximately $1 per 100km, compared to $15–$20+ on petrol.

---

*Previous: [Module 5 — Commercial Solar](05-commercial.md) | Next: [Module 7 — QLD Programs 2026](07-qld-programs.md)*
